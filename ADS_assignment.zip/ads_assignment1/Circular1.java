package ads_module1;

class Circular1
{
   
   public  class Node
    {
        int data;
        Node next;
        
        public Node(int data)
        {
            this.data=data;
        }
    }
   //Declaring head and tail pointer as null
   
  Node head=null;
  Node tail=null;
   
   public void add(int data)
   {
       Node newnode=new Node(data);
       if(head==null)
       {
           head=newnode;
           tail=newnode;
           newnode.next=head;
       }
       else
       {
           tail.next=newnode;
           tail=newnode;
           tail.next=head;
       }
   }  
   
   //Delete an element
  
       
   
     //Displays all the nodes in the list  
    public void display() {  
        Node current = head;  
        if(head == null) {  
            System.out.println("List is empty");  
        }  
        else {  
            System.out.println("Nodes of the circular linked list: ");  
             do{  
                //Prints each node by incrementing pointer.  
                System.out.print(" "+ current.data);  
                current = current.next;  
            }while(current != head);  
            System.out.println();  
        }  
    }  
  
    public static void main(String[] args) {  
        Circular1 cl = new Circular1();  
        //Adds data to the list  
        cl.add(1);  
        cl.add(2);  
        cl.add(3);  
        cl.add(4);  
        //Displays all the nodes present in the list  
        cl.display();  
    }  
}  

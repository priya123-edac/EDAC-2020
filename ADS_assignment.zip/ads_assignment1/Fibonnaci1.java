package Ass1;

//Using for loop
/*public class Fibonnaci1
{
    public static void main(String args[])
    {
      int max_number=10;
      int prev_num=0;
      int next_num=1;
      
        System.out.println("Fibonacci series of "+max_number+"numbers");
        for (int i = 1; i <= max_number; ++i)
	        {
	            System.out.print(prev_num+" ");
	           
	            int sum = prev_num + next_num;
	            prev_num = next_num;
	            next_num = sum;
	        }
	}
}*/

//fibonacci series based on the user input
/*import java.util.Scanner;
public class Fibonnaci1 {
 
	public static void main(String[] args) 
	{
	
		 int maxNumber = 0; 
		 int previousNumber = 0;
		 int nextNumber = 1;
		 
		    System.out.println("How many numbers you want in Fibonacci:");
	        Scanner scanner = new Scanner(System.in);
	        maxNumber = scanner.nextInt();
	        System.out.print("Fibonacci Series of "+maxNumber+" numbers:");
 
	        for (int i = 1; i <= maxNumber; ++i)
	        {
	            System.out.print(previousNumber+" ");
	            int sum = previousNumber + nextNumber;
	            previousNumber = nextNumber;
	            nextNumber = sum;
	        }
	}
}*/

//Fibonnacii series using recursion 
//Using Recursion
public class Fibonnaci1{
	public static int fibonacciRecursion(int n){
	if(n == 0){
		return 0;
	}
	if(n == 1 || n == 2){
			return 1;
		}
	return fibonacciRecursion(n-2) + fibonacciRecursion(n-1);
	}
    public static void main(String args[]) {
	int maxNumber = 10;
	System.out.print("Fibonacci Series of "+maxNumber+" numbers: ");
	for(int i = 0; i < maxNumber; i++){
			System.out.print(fibonacciRecursion(i) +" ");
		}
	}
}


        
        
    
              
    

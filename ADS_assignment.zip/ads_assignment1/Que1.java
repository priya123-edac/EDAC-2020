package ads_module1;

class Queue
{
private static int front,rear,capacity;
private static int queue[];
Queue(int size)
{
    front=rear=0;
    capacity=size;
    queue=new int[capacity];
}   
    //insert an element into the queue
    static void queueEnqueue(int item)
    {
      //check if the queue is full
        if(capacity==rear)
        {
            System.out.println("\nQueue is full!!");
        }
        else
        {
          queue[rear]=item;
          rear++;
        }
        return;
    }
    
    
    //delete an element from the queue
    static void queueDequeue()
    {
        //check if queue is empty or not
      if(front==rear)
      {
          System.out.println("Queue is empty!!");
          return;
      }
      //shift elements to the right by one until rear
      else
      {
          for(int i=0;i<rear-1;i++)
          {
              queue[i]=queue[i+1];
              
          }
          //set queue[rear] to 0
          if(rear<capacity)
         queue[rear]=0;
          //decrement rear
          rear--;
      }
      return;
    }
    
    //print queue elements
    static void queueDisplay()
    {
        int i;
        if(front==rear)
        {
            System.out.println("Queue is empty!!");
            return;
        }
         // traverse front to rear and print elements 
        for ( i = front; i < rear; i++) { 
            System.out.printf(" %d = ", queue[i]); 
        } 
        return;
    
    }
     // print front of queue 
    static void queueFront() 
    { 
        if (front == rear) { 
            System.out.printf("Queue is Empty\n"); 
            return; 
        } 
        System.out.printf("\nFront Element of the queue: %d", queue[front]); 
        return;
        
    } 


}
public class Que1
{
public static void main(String args[])
{
    //create a queue of capacity 4
   Queue q1=new Queue(4); 
   //inserting elements in the queue
   q1.queueEnqueue(5);
   
}
}

package ads_assignment1;
import java.util.Scanner;

//Factorial without recursion
/*
public class Factorial_1
{
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      int n=sc.nextInt();
      int fact=1;
      for(int i=0;i<n;i++)
      {
          fact=fact*i;
      }
        System.out.println("Factorial of a number is:"+fact);
    }
}
*/

//Factorial using recursion
import java.util.Scanner;
public class Factorial_1
{
    
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int  n=sc.nextInt();
        System.out.println("Factorial of a num is:"+fact(n));
        
    }
    public static long fact(int num)
    {
        if(num<=1)
        {
            return 1;
        }
        
        return num*fact(num-1);
         
    }
}


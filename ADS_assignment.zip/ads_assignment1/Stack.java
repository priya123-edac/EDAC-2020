package ads_module1;

import static ads_module1.Stack3.max;

class Stack
{
    private int arr[];
    private int capacity;
    private int top;
   
    //create a stack
    Stack(int size)
    {
        arr=new int[size];
        capacity=size;
        top=-1;
    }

    Stack() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    //inserting element into a stack
    public void push(int item)
    {
        if(isFull())
        {
            System.out.println("Stack overflow\nProgram terminated!!");
            System.exit(1);
       }
        System.out.println("Inserting:"+item);
        arr[++top]=item;
    }
    
    
    //remove an element from stack
    public int pop()
    {
        if(isEmpty())
        {
            System.out.println("Stack empty!!");
            System.exit(1);
        }
        return arr[top--];
    }
    
    //utility function to return size of the stack
    public int size()
    {
     return (top + 1) ;
    }
    
    
    public Boolean isFull()
    {
        return top == capacity-1;
    }
    
    
    public boolean isEmpty()
    {
        return top==-1;
    }
       int a[]=new int[max]; 
    int Top; 
    void peek() 
    { if(isEmpty())
    { System.out.println("stack is Underflow"); 
    } else { System.out.print("top value "+Top+" "+a[Top]); } 
    for(int i:a)
    { 
        System.out.println("\n"+i);
    } }
    public void printstack()
    {
        for(int i=0;i<top;i++)
        {
            System.out.println(arr[i]);
        }
    }
    public static void main(String args[])
    {
      Stack obj=new Stack(3);
    
      
      
      
     
    }
}
package ads_module1;

class Node
{
    int data;
    Node next;
}

class Runner
{
    Node head;
    
    public void insert(int data)
    {
       
        Node node =new Node();
        node.data=data;
        node.next=null;
        if(head==null)
        {
            head=node;
        }
        else
        {
            Node n=head;
       
        while(n.next!=null)
        {
            n=n.next;
        }
        n.next=node;
   }
    }       
        public void show()
        {
          Node node=head;
          while(node.next!=null)
          {
              System.out.println(node.data);
              node=node.next;
          }
          System.out.println(node.data);
        }
}
public class Linkedlist1
{
    public static void main(String args[])
    {
     Runner obj=new Runner();
     obj.insert(15);
     obj.insert(20);
     obj.insert(28);
     obj.insert(45);
     obj.show();
    }
}
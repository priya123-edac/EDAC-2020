import java.util.*;

//Bubble sort algorithm using arrays
/*
public class Sorting_Algo
{
  public void  bubbleSort(int arr[])
    {
      int n=arr.length;
      for(int i=0;i<n-1;i++)
      {
          for(int j=0;j<n-i-1;j++)
          {
           
              if(arr[j]>arr[j+1])
              {
                  int temp=arr[j];
                  arr[j]=arr[j+1];
                  arr[j+1]=temp;
              }
          }
      }
    }
  public void printArray(int arr[])
   {
    int n=arr.length;
    for(int i=0;i<n;i++)
    {
        System.out.print(arr[i]+" ");
  
    }
          System.out.println();
   }
    
    public static void main(String[] args)
    {
        Sorting_Algo obj=new Sorting_Algo();
        int arr[]={64,34,12,22,11,90};
        obj.bubbleSort(arr);
        System.out.println("Sorted array is:");
        obj.printArray(arr);
    }
}*/

//Selection sort algorithm using arrays
/*
public class Sorting_Algo
{
    public void selectionSort(int arr[])
    {
    int n=arr.length;
for(int i=0;i<n-1;i++)
{
    //find minimum index element
    int min_index=i;
    for(int j=i+1;j<n;j++)
    {
        if(arr[j]<arr[min_index])
        {
            min_index=j;
            
            int temp=arr[min_index];
            arr[min_index]=arr[i];
            arr[i]=temp;
        }
    }
}
 }
    
    public void printArray(int arr[])
    {
        int n=arr.length;
        for(int i=0;i<n;i++)
        {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
  public static void main(String[] args)
    {
        Sorting_Algo obj=new Sorting_Algo();
        int arr[]={54,56,80,10,5,90};
        obj.selectionSort(arr);
        System.out.println("Sorted array is:");
        obj.printArray(arr);
    }
}*/

//Java Implementation of insertion sort as follows:
/*
public class Sorting_Algo
{
    void insertionSort(int arr[])
    {
        int n=arr.length;
        for(int i=1;i<n;++i)
      {
           int key=arr[i];
           int j=i-1;
           
           while(j>=0 && arr[j]>key)
           {
               arr[j+1]=arr[j];
               j=j-1;
               
           }
           arr[j+1]=key;
        }
    }
    void printArray(int arr[])
    {
        int n=arr.length;
        for(int i=0;i<n;i++)
        {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
    
    
    
    public static void main(String args[])
    {
        Sorting_Algo obj=new Sorting_Algo();
        int arr[]={54,25,65,89,10,2};
        obj.insertionSort(arr);
        System.out.println("After sort:");
        obj.printArray(arr);
    }
}*/
// Java implementation of merge sort
/*
class Sorting_Algo
{
    void merge(int arr[],int p,int q,int r)
    {
        //L<-A[p...q] && M<-A[P+1...r]
        int n1=q-p+1;
        int n2=r-q;
        
        //array L & M
        int L[]=new int[n1];
        int M[]=new int[n2];
        
        //For loops
        for(int i=0;i<n1;i++)
        {
            L[i]=arr[p+i];
        }
        for(int j=0;j<n2;j++)
        {
         M[j]=arr[q+1+j];   
        }
        
        //maintain index for all
        int i,j,k;
        i=0;
        j=0;
        k=p;
        
        while(i<n1 && j<n2)
        {
            if(L[i]<=M[j])
            {
              arr[k]=L[i];
              i++;
            }
            else
            {
             arr[k]=M[j];
             j++;
            }
            k++;
        }
        
        while(i<n1)
        {
            arr[k]=L[i];
            i++;
            k++;
        }
        while(j<n2)
        {
            arr[k]=M[j];
            j++;
            k++;
        }
    }
    
    void mergeSort(int arr[],int l,int r)
    {
        if(l<r)
        {
            int m=(l+r)/2;
            mergeSort(arr,l,m);
            mergeSort(arr,m+1,r);
            merge(arr,l,m,r);
        }
    }
    
    void printArray(int arr[])
    {
        int n=arr.length;
        for(int i=0;i<n;++i)
        {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
    
 public static void main(String args[])
 {
     Sorting_Algo obj=new Sorting_Algo();
     int arr[]={50,50,60,10,30,4};
     obj.mergeSort(arr,0,arr.length-1);
     System.out.println("Sorted array is:");
     obj.printArray(arr);
     
}
}*/
//Java implementation of Quick sort algorithm 
public class Sorting_Algo
{
     int partition(int arr[], int low, int high) 
    { 
        int pivot = arr[high];  
        int i = (low-1); // index of smaller element 
        for (int j=low; j<high; j++) 
        { 
            // If current element is smaller than the pivot 
            if (arr[j] < pivot) 
            { 
                i++; 
  
                // swap arr[i] and arr[j] 
                int temp = arr[i]; 
                arr[i] = arr[j]; 
                arr[j] = temp; 
            } 
        } 
  
        // swap arr[i+1] and arr[high] (or pivot) 
        int temp = arr[i+1]; 
        arr[i+1] = arr[high]; 
        arr[high] = temp; 
  
        return i+1; 
    } 
     void sort(int arr[], int low, int high) 
    { 
        if (low < high) 
        { 
            /* pi is partitioning index, arr[pi] is  
              now at right place */
            int pi = partition(arr, low, high); 
  
            // Recursively sort elements before 
            // partition and after partition 
            sort(arr, low, pi-1); 
            sort(arr, pi+1, high); 
        } 
    } 
  
    /* A utility function to print array of size n */
    static void printArray(int arr[]) 
    { 
        int n = arr.length; 
        for (int i=0; i<n; ++i) 
            System.out.print(arr[i]+" "); 
        System.out.println(); 
    } 
  
    // Driver program 
    public static void main(String args[]) 
    { 
        int arr[] = {10, 7, 8, 9, 1, 5}; 
        int n = arr.length; 
  
        Sorting_Algo ob = new Sorting_Algo(); 
        ob.sort(arr, 0, n-1); 
  
        System.out.println("sorted array"); 
        printArray(arr); 
    } 
} 

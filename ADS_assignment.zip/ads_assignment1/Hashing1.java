package ads_module1;
import java.util.*;

class Hashing1
{
   public static void convert(int arr[],int n)
    {
       //create a temp array and copy content of arr[] to temp[]
        int temp[]=arr.clone();
        
        //Sort temp array
        Arrays.sort(temp);
        
        //create hash table
        HashMap<Integer,Integer> umap=new HashMap<>();
        
        //insert one by one element of temp[] and assign them values from 0 to n-1
        int val=0;
        for(int i=0;i<n;i++)
        {
            umap.put(temp[i],val++);
        }
        
        //convert array by taking positions from umap
        for(int i=0;i<n;i++)
        {
            arr[i]=umap.get(arr[i]);
        }
    }
    
   public static void  printArr(int arr[],int n)
    {
        for(int i=0;i<n;i++)
        {
            System.out.print(arr[i]+" ");
        }
    }
    public static void main(String args[])
    {
        int arr[]={20,15,40,30,60,2,3};
        int n=arr.length;
        System.out.println("Given array is:");
        printArr(arr,n);
        convert(arr,n);
        System.out.println("\n"+"Converted array is:");
        printArr(arr,n);
    }
}
//Linked list traversal
/*
class Linked_List
{
  Node head;

static class Node
{
    int data;
    Node next;
    
    Node(int data){
        this.data=data;
        this.next=null;
    }
}

public void printList()
{
    Node n=head;
    while(n!=null)
    {
        System.out.print(n.data+" ");
        n=n.next;
    }
}
    
public static void main(String args[])
{
 Linked_List ob=new Linked_List();
ob.head=new Node(1);
Node second=new Node(2);
Node third=new Node(3);
 
ob.head.next=second;
second.next=third;
 
ob.printList();
    
}
}*/

//Insertion in linked list

class Linked_List
{
    Node head;
    static class Node
    {
        int data;
        Node next;
        Node(int data)
        {
            this.data=data;
            this.next=null;
        }
    }
    
    public void push(int new_data)
    {
       Node new_node=new Node(new_data);
       new_node.next=head;
       head=new_node;
    }
    
    public void insert_After(Node prev_node,int new_data)
    {
        if(prev_node==null)
        {
            System.out.println("This prev node can not be null!!");
            return;
        }
        Node new_node=new Node(new_data);
        new_node.next=prev_node.next;
        prev_node.next=new_node;
        
    }
    
    public void insert_End(int new_data)
    {
        Node new_node=new Node(new_data);
        if(head==null)
        {
            head=new Node(new_data);
            return;
        }
        new_node.next=null;
        //else traverser till last node
        Node last=head;
        if(last!=null)
        {
            System.out.println(last.data+" ");
            last=last.next;
            return;
        }
    }
    
    public void deleteNode(int key)
    {
Node temp=head,prev=null;

if(temp!=null & temp.data==key)
{
    head=temp.next;
    return;
}
while(temp!= null && temp.data !=key)
{
    prev=temp;
    temp=temp.next;
    
}
if(temp==null) return;
prev.next=temp.next;
    }
    
    public void printList()
    {
        Node n=head;
        while(n!=null)
        {
            System.out.print(n.data+" ");
            n=n.next;
        }
    }
    public static void main(String args[])
    {
        Linked_List llist=new Linked_List();
                llist.push(7); 
        llist.push(1); 
        llist.push(3); 
        llist.push(2); 
  
        System.out.println("\nCreated Linked list is:"); 
        llist.printList(); 
  
        llist.deleteNode(1); // Delete node with data 1 
  
        System.out.println("\nLinked List after Deletion of 1:"); 
        llist.printList(); 

    }
}
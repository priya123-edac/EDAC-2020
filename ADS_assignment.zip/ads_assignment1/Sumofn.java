package Ass1;
import java.util.Scanner;

public class Sumofn
{
    public static void main(String args[])
    {
        Sumofn ne=new Sumofn();
        Scanner sc=new Scanner(System.in);
       
        System.out.println("Enter the number of elements u want to enter!");
         int n=sc.nextInt();
         int sum=0;
        System.out.println("Enter the elemnts:");

        for(int i=0;i<n;i++)
        {
            int arr[]=new int[n];
            arr[i]=sc.nextInt();
            sum=sum+arr[i];
        }
        System.out.println("SUm of"+n+"elements is:"+sum);
    }
}
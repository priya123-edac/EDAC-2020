package ads_module1;
import java.util.*;

class Sorting1
{
    void bubblesort(int arr[])
    {
        
    }
    
    void printArray()
    {
        
    }
    
    
    
    public static void main(String args[])
    {
        
        Scanner sc=new Scanner(System.in);
         Sorting1 obj=new Sorting1();

        System.out.println("Enter the size of the array!!");
        int n=sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter array elements");
          for(int i=0;i<n;i++)
          {
              arr[i]=sc.nextInt();
          }
          for(int i=0;i<n;i++)
          {
              System.out.println("Array elements before sorting are:"+arr[i]);
          }
        obj.bubblesort(arr);
        
    }
}
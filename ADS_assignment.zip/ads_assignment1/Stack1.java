package ads_module1;
import java.util.Scanner;

class Stack1
{
      static Scanner sc=new Scanner(System.in);
      static int Stack[],top=-1,size;
      
      static
      {
       Stack1.create();   
      }
      
    public static void main(String args[])
    {
        int ch,item;
        while(true)
        {
        System.out.println("Push");
        System.out.println("Pop");
        System.out.println("Peek");
        System.out.println("Traverse");
        System.out.println("Quit");
        System.out.println("Enter your choice:");
        ch=Stack1.sc.nextInt();

        switch(ch)
        {
            case 1:System.out.println("Enter element to push"); 
                   item=sc.nextInt();
                    push(item);
                    break; 
                    
            case 2: item=Stack1.pop();
            if(item==0)
            {
                System.out.println("Stack is underflow\n");
            }
            else
            {
                System.out.println("Popped item:"+item);
            }
                    break;
                    
            case 3:item=Stack1.peek();
            if(item==0)
            {
                System.out.println("Stack is underflow\n");
            }
            else
            {
                System.out.println("Popped item:"+item);
            }
                    break;
                    
            case 4:Stack1.traverse();
                    break;
            case 5:System.exit(1);
            default:System.out.println("Invalid choice\n");   
          
        }
     
        }
  }
    
    //method to create a stack 
    private static void create()
    {
        System.out.println("Enter size of a stack");
        size=Stack1.sc.nextInt();
        Stack1.Stack=new int[size];
        System.out.println("Stack created successfully with size:"+size);
    }
    //Push operation 
    static void push(int item)
    {
        if(Stack1.isFull())
        {
            System.out.println("Stack is overflow\n");   
        }
        else
        {
           Stack[++top]=item ;
        }
        
    }
    
   private static boolean isFull()
              {
              if(top==size-1)
               {
                   return true;
               }
               else
               {
               return false;
               }
              }
   
   //Pop operation 
static int  pop()
{
    if(Stack1.isEmpty())
    {
return 0;    
    }
    else
    {
       return Stack[top--]; 
    }
        
}

//To check about empty condition
static boolean isEmpty()
{
    if(top == -1)
    {
        return true;
    }
    else
    {
        return false;
    }
    
}
static int  peek()
{
    if(Stack1.isEmpty())
    {
return 0;    
    }
    else
    {
       return Stack[top]; 
    }
        
}

private static void traverse()
{
    if(Stack1.isEmpty())
    {
        System.out.println("Stack is empty\n");
    }
    else
    {
        System.out.println("Elements of stack");
        for(int i=top;i>=0;i--)
        {
            System.out.println(Stack[i]);
        }
    }
}


}

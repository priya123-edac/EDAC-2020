package ads_module1;
//Simple program for traversal of linkedlist

class Linkedlist_Example
{
     Node head;//head of the list
     
     //inner class is made static so that main can access it.
    static class Node
    {
     int data;
     Node next;
     Node(int d)
     {
         data=d;
         next=null;
  }//constructor
     
    }
    public void printList()
     {
         Node n=head;
         while(n!=null)
         {
             System.out.println(n.data+" ");
             n=n.next;
         }
     }
     
    //method to create a simple linked list with three nodes.
    public static void main(String args[])
    {
        //start with empty linkedlist
        Linkedlist_Example obj=new Linkedlist_Example();
        
        obj.head=new Node(1);
        Node second=new Node(2);
        Node third=new Node(3);
        
        
        obj.head.next=second;//Link first node with second node
        second.next=third;//Link second node with third node
        
        //print the content of linked list
        obj.printList();
    }
}
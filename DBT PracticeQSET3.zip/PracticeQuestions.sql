create database Pract2;
use Pract2;
-- create table superhero
CREATE TABLE SUPERHERO (ID INT(10)  ,NAME VARCHAR(20),LATTITUDE FLOAT(20),LONGITUDE FLOAT(20),PRIMARY KEY(ID));

DESC SUPERHERO;

INSERT INTO SUPERHERO VALUES(1,'Btaman',50.23,85.45),
(2,'Spiderman',65.43,65.66),
(3,'Thor',45.34,30.89),
(4,'Iron Man',85.34,80.98),
(5,'Deadpool',25.12,69.21),
(6,'Hulk',30.34,20.98),
(7,'Doctor Strange',40.45,40.56),
(8,'Captain America',70.00,75.32),
(9,'Avengers',81.32,90.84),
(10,'Superman',85.32,45.78);
SELECT * FROM SUPERHERO;

select superhero.name from superhero  where length(name)<7 order by id ASC limit 7  ;

select id from superhero where LATTITUDE<50 and LONGITUDE <50;

-- Q2)The superheros Location
CREATE TABLE SUPERHERO (ID INT(10)  ,NAME VARCHAR(20),LATTITUDE FLOAT(20),LONGITUDE FLOAT(20),PRIMARY KEY(ID));


INSERT INTO SUPERHERO VALUES(1,'Btaman',50.23,85.45),
(2,'Spiderman',65.43,65.66),
(3,'Thor',45.34,30.89),
(4,'Iron Man',85.34,80.98),
(5,'Deadpool',25.12,69.21),
(6,'Hulk',30.34,20.98),
(7,'Doctor Strange',40.45,40.56),
(8,'Captain America',70.00,75.32),
(9,'Avengers',81.32,90.84),
(10,'Superman',85.32,45.78);
SELECT * FROM SUPERHERO;


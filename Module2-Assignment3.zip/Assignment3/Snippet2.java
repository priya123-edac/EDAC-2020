package Assignment3;

public class Snippet2 {

	public static void main(String[] args) {
		

			/*

				int a=-5;
			      	int b=3; 
			      	int c=0; 
			      	int  d;
			     
			     	d = a++ | ++b   & c++;
			      
			      	System.out.println(a + " " + b +"  "+  c  +" " +d);

			*/

			/*

			        if (true) 
				   	break;
				 if (true) 
		            		continue;


			*/
			

			/*

				int x= 0; int y= 0;
				for (int z = 0; z < 5; z++)
				{
					if (( ++x > 2 ) && (++y > 2))
					{
						x++;
					}
				}
				System.out.println(x + " " + y);
				System.out.println((( ++x > 2 ) && (++y > 2)));

			*/


			
			System.out.println("j" + "a" + "v" + "a");
			System.out.println('j' + 'a' + "v" + 'a'); //106+97+118+97
				
			

			/*

				int x = 15; 		
			        int y = 16; 
		   
		  
			        System.out.println("x & y = " + (x & y)); 
		   
			        System.out.println("x | y = " + (x | y)); 
		   
			        System.out.println(" x ^ y = " + (x ^ y)); 
		   
			        System.out.println("~x = " + ~x); 
		   
			        System.out.println("x= " + x); 	

			*/

			/*
			
				int x = 5;
				//int y = (x > 3 && x < 10);
				//System.out.print(y);
				System.out.println(x > 3 && x < 10); 

			*/
		   



		/*

		public class Demo{ 
		    public static void main(String[] arr){ 
		          
		    } 
		    public static void main(String arr){ 
		          
		    } 
		} 


		*/
	}

}

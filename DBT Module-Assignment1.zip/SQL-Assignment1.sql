create database assignment1;
use assignment1;

#1)create all tables
create table Members(Member_id numeric(5),Member_name varchar(30),Member_address varchar(50),Acc_open_date date,Membership_type varchar(50),penalty_amount numeric(7));
create table Books(Book_No Numeric(6),Book_Name varchar(30),Author_name varchar(30),Cost Numeric(7),Category Char(10));
create table Issue(Lib_issue_id numeric(10),Book_No numeric(6),Member_Id numeric(5),Issue_Date date,Return_Date date);

#2)view all table structure
select * from Members;
select * from Books;
select * from Issue;

#3)delete a column Penalty_amount from table Members
alter table Members drop column Penalty_amount ;

#4)Insert into  a table Members=>It contains information about members
insert into Members values(1,'Priyanka Ligade','Navi Mumbai','1996-12-23','Lifetime');
insert into Members values(2,'Pratiksha Khade','Navi Mumbai',STR_TO_DATE('05-DEC-2020','%d-%M-%Y'),'Annual');
insert into Members values(3,'Pooja Derle','Nashik',STR_TO_DATE('15-DEC-2020','%d-%M-%Y'),'Combined');
insert into Members values(4,'Pranali Deshmuksh','Pune',STR_TO_DATE('30-DEC-2020','%d-%M-%Y'),'Half Yearly');
insert into Members values(5,'Mrunmai Chavan','Pune',STR_TO_DATE('4-DEC-2020','%d-%M-%Y'),'Half Yearly');

#5)view data of table Members
select * from Members;

#6)Insert into table Books->It contains information about the books belongs to the library
insert into Books values(101,'Let us C','Dennis Ritchie',450,'System');
insert into Books values(102,'Oracle-CompleteRef','Loni',550,'Database');
insert into Books values(103,'Mastering SQL','Loni',250,'Database');
insert into Books values(104,'PL SQL-Ref','ScottUrman',750,'Database');

#7)view data in table Books
 select * from Books;
 
 #8)update price and category of the book with id 103
 SET SQL_SAFE_UPDATES=0;
 update Books SET Cost=300 , Category='RDBMS' WHERE Book_No =103;
 
 #9)Drop table Issue;
 drop table Issue;

#10)Insert into  table Issue=> It contains information about issue of the books
insert into Issue values(7001,101,1,STR_TO_DATE('10-Dec-2006','%d-%M-%Y'),STR_TO_DATE('20-Dec-2006','%d-%M-%Y'));
insert into Issue values(7002,102,2,STR_TO_DATE('1-Jan-2006','%d-%M-%Y'),STR_TO_DATE('20-Jan-2006','%d-%M-%Y'));
insert into Issue values(7002,102,3,STR_TO_DATE('15-Dec-2006','%d-%M-%Y'),STR_TO_DATE('30-Dec-2006','%d-%M-%Y'));

#11) Drop the table Issue and create new one with blank return date column values
drop table Issue;

#12)Create table Issue again and insert data into it.
create table Issue(Lib_issue_id numeric(10),Book_No numeric(6),Member_Id numeric(5),Issue_Date date,Return_Date date);

insert into Issue (Lib_issue_id,Book_No,Member_Id,Issue_Date) values(7001,101,1,STR_TO_DATE('10-Dec-2006','%d-%M-%Y'));
insert into Issue (Lib_issue_id,Book_No,Member_Id,Issue_Date) values(7002,102,2,STR_TO_DATE('25-Dec-2006','%d-%M-%Y'));
insert into Issue (Lib_issue_id,Book_No,Member_Id,Issue_Date) values(7003,104,1,STR_TO_DATE('15-Jan-2006','%d-%M-%Y'));
insert into Issue (Lib_issue_id,Book_No,Member_Id,Issue_Date) values(7004,101,1,STR_TO_DATE('04-July-2006','%d-%M-%Y'));
insert into Issue (Lib_issue_id,Book_No,Member_Id,Issue_Date) values(7005,104,2,STR_TO_DATE('15-Nov-2006','%d-%M-%Y'));
insert into Issue (Lib_issue_id,Book_No,Member_Id,Issue_Date) values(7006,101,3,STR_TO_DATE('18-Feb-2006','%d-%M-%Y'));

#created table Issue with blank return date column
#to view the content of the Issue table
select * from Issue;
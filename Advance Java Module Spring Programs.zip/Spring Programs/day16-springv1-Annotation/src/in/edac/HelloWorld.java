package in.edac;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloWorld {
	//To make program spring aware
	
	@Autowired
	private UserDao userDao;

	private static final ApplicationContext context =  new ClassPathXmlApplicationContext("spring.xml");
public static void main(String args[])
{
	System.out.println("Hellloooo");

	//System.out.println(context);
}
	

}

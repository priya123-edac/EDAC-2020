package in.edac;

import java.util.Arrays;
import java.util.List;

import javax.persistence.MappedSuperclass;

import org.springframework.stereotype.Controller;

@Controller
@RequestMapping
public class MyRestActions {
	
	
	@GetMapping("/")
	public String sayHii()
	{
		return "Helllooo";
	}
	
	
	@GetMapping("/list")
	public List<String>  myList()
	{
		return Arrays.asList("Delhi","Kolkata","Pune","Mumbai");
	}
	
	@PostMapping("/register")
	public void fileUploadRestDemo()
	{
		
	}

}

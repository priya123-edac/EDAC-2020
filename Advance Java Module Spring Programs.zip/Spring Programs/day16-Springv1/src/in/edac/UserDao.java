package in.edac;


public class UserDao {
	public void sayHi() {
		System.out.println("Helloooooo!!!!");
	}

}



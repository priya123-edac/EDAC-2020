//JavaScript Assignment 2
//1)With example illustrate variable and function closure in javascript.

function Counter()
{
	var counter=0;
	 function increaseCounter()
	 {
		 return counter++;
	 };
	 return increaseCounter;
}

	 var count=Counter();
	 console.log(count());
	  console.log(count());
	   console.log(count());
	 //2.Write a javascript function named reverse which takes a string argument and returns the reversed string. 
	 
	 
	  function reversestring(s)
	  {
		  return s.split("").reverse().join("");
		  
	  }
	  reversestring("Hello");
	  //3.Given a javascript array of objects having a radius property as shown [{radius: 5}, {radius: 9}, {radius: 2}], 
	 // write a comparator function to sort it.
	  function func()
	  {
		  var arr=[ 15,  19,  21];
		  console.log(arr.sort());
	  }
	  func();
	  //4.Write a Javascript program to sort elements of an array using sorting algorithm
	   function fruits()
	  {
		  var arr=["Banana","Orange","Apple","Mango"];
		  console.log(arr.sort());
	  }
	 fruits();
	 //5.Write a javascript function named length_of_array, which takes an array
	 //as argument and returns the number of elements in that array (as opposed to what is given by the length property of the array). Remember undefined can also be an element if it is explicitly set at some index, e.g. x[5] = undefined;. This undefined should be counted, but elements which are not present 
	 //in the array (as arrays can be sparse), should not be counted.
	    var array=["first","second","third"];
		array.forEach(function(element)
		{
			console.log(element);
		})
		if(array[2]===undefined)
		{
			console.log("array[2] is undefined");
		}
		array=["first","second",undefined,"third"];
		array.forEach(function(element)
		{
			console.log(element);
		})
		
	//6)With suitable example explain OOL concepts in javascript like Inheritance, 
	//Constructor, Encapsulation and Abstraction .	
     var Person=function(firstname,lastname)
	 {
		 this.firstname=firstname;
		 this.lastname=lastname;
	 };
	 
	 Person.prototype.walk=function()
	 {
		 console.log(this.firstname + " is walking");
	 };
	 
	 Person.prototype.sayhello=function()
	 {
		 console.log("Hello I am "+this.firstname );
	 };
	 
	function Student(firstname,subject,lastname)
	{
		Person.call(this,firstname,lastname);
		this.subject=subject;
		
	}
	Student.prototype=Object.create(Person.prototype);
	
	Student.prototype.constructor=Student;
	Student.prototype.sayhello=function()
	{
		console.log("hello" +this.firstname +""+this.subject + " "+this.lastname);
	};
	
	Student.prototype.saygoodbye=function()
	{
		console.log("goodbye");
	};
	var stud=new Student("Priyanka ","Ligade","Web development");
	stud.sayhello();
	stud.walk();
	stud.saygoodbye();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
package Bank_pck;
import java.util.Scanner;
class BankApp
{
    int acc_num;
    String name_1;
    float bal=0;
    int cut_id;
   void createAccount()
    {
     Scanner sc=new Scanner(System.in);
        System.out.print("Enter your account number:\n");
        int acc_No=sc.nextInt();
        System.out.print("Enter your Name:");
        String name_1=sc.next();
        System.out.print("Enter your customer Id:");
        int cut_Id=sc.nextInt();
        System.out.println("Congratulations"+name_1+ "account has been created!!");
        System.out.println("Enter account opening amount:");
         float amount=sc.nextFloat();
        if(amount<500)
        {
            System.out.println("Sorry,Minimum account opening amount is 500!!");
        }
        else 
        {
            bal+=amount;
            System.out.println(amount +"Rs. is deposited to your account!!");
        }
    }     
   
   void deposit()
    {
        System.out.println("Enter the amount you want to deposit:");
   
    Scanner sc=new Scanner(System.in);
    float amount;
        System.out.println("Enter Amount to be Deposited:");
        amount = sc.nextFloat();
        bal = bal+amount;
        System.out.println("Deposited! Account Balance is "+bal);
    
}
 void withdraw()
   {
        
      System.out.println("Enter amount to withdraw:");
      Scanner sc=new Scanner(System.in);
      float amount=sc.nextFloat();
      if(amount<=0)
      {
          System.out.println("withdrawal can not be completed!!");
      }
      else
      {
       bal-=amount;
       System.out.println("Balance after withdrawal is:"+bal);
      }
   }
   void checkBalance()
   {
       System.out.println("Your balance is:"+bal);
   }
   
}  
    class Bank_2
    {
    public static void main(String args[])
    {
      BankApp obj1=new BankApp(); 
      obj1.createAccount();
   
     System.out.println("Enter your choice:\n1.Deposit Money\n2.Withdraw Money\n3.Check Balance\n");
     //Accept user input
          
      Scanner sc=new Scanner(System.in);
        int choice=sc.nextInt();
        
        boolean exit=false;
      String a;
             
        do
        {
            
              switch(choice)
                  {
             
              case 1:
                 
                   obj1.deposit();
                  break;
                   
               case 2:
                   System.out.println("Let's proceed for money withdrawal!!");
                   obj1.withdraw();
                   break;
                   
              case 3:
                  System.out.println("Let's proceed to check balance!!");
                 obj1.checkBalance();
                  break;
                  
              case 0:
                  exit=true;
                  System.out.println("Exit from Application!!");
                  break;
                  
              default:
                  System.out.println("Invalid choice!!");     
            
           }
                    System.out.println("Do you want to continue Y/N");
                a=sc.nextLine();
                 
        }while("Y".equals(a) || "y".equals(a));
           }
       }
      
    
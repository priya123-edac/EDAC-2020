package Bank_pck;
import java.util.Scanner;

 class Bank_1
{
   
  
   public static void main(String args[])
   {
           
       System.out.println("Enter your choice:\n1.Open Account\n2.Deposit Money\n3.Withdraw Money\n4.Check Balance\n");
     //Accept user input
          
  Scanner sc=new Scanner(System.in);
        int choice=sc.nextInt();
        boolean exit=false;
 
       
      
       while(choice!=0)
       {
         
           if(choice<0 && choice>5)
           {
             System.out.println("Invalid choice!!");
           }
           else if(choice>0 && choice<=5)
           {
                  switch(choice)
           {
               case 1:
                   System.out.println("Let's open a new account!!");
                   createAccount();
                   break;
               
               case 2:
                
                   System.out.println("Let's proceed for money deposit!!");
                   deposit();
                   break;
                   
               case 3:
                   System.out.println("Let's proceed for money withdrawal!!");
                   withdraw();
                   break;
                   
              case 4:
                  System.out.println("Let's proceed to check balance!!");
                 // checkBalance();
                  break;
                  
              case 0:
                  exit=true;
                  System.out.println("Exit from Application!!");
                  break;
                  
              default:
                  System.out.println("Invalid choice!!");     
           }
               
           }
       }
      
        
       
    }
            
    
    
    public static void createAccount(){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter your account number:\n");
        int acc_No=sc.nextInt();
        System.out.print("Enter your Name:");
        String name_1=sc.next();
        System.out.print("Enter your customer Id:");
        int cut_Id=sc.nextInt();
        System.out.println("Congratulations"+name_1+ "account has been created!!");
        System.out.println("Enter account opening amount:");
         float amount=sc.nextFloat();
        if(amount<500)
        {
            System.out.println("Sorry,Minimum account opening amount is 500!!");
        }
        else 
        {
            System.out.println(amount +"Rs. is deposited to your account!!");
        }

   }
    
    public static void deposit()
{
     float bal=0;
    System.out.println("Enter the amount you want to deposit:");
    Scanner sc=new Scanner(System.in);
    float amount=sc.nextFloat();
    if(amount<=0)
    {
        System.out.println("A nonpositive number cannot be deposited");
    }
    else 
    {
   bal=bal+amount;
    System.out.println("Deposit successful!!");
    }
      
    }
   public static void withdraw()
   {
       float bal=0;  
      System.out.println("Enter amount to withdraw:");
      Scanner sc=new Scanner(System.in);
      float amount=sc.nextFloat();
      if(amount<=0)
      {
          System.out.println("withdrawal can not be completed!!");
      }
      else
      {
       bal-=amount;
       System.out.println("Balance after withdrawal is:"+bal);
      }
   }
   
 }




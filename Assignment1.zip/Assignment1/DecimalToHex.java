import java.util.Scanner;
public class DecimalToHex{
     
public static void main(String a[]){
int i;
Scanner sc=new Scanner(System.in);
i=sc.nextInt();
sc.close();
System.out.println(Integer.toHexString(i)); //converts decimal number into binary format
}
}

import java.util.Scanner;
public class BinaryToHex{
public static void main(String args[])
{
int num;
Scanner sc= new Scanner(System.in);
System.out.println("Binary to HexaDecimal");

		
System.out.println("\nEnter the number :");
num = Integer.parseInt(sc.nextLine(), 2);
sc.close();

String hexa = Integer.toHexString(num);
System.out.println("HexaDecimal Value is : " + hexa);
}
}
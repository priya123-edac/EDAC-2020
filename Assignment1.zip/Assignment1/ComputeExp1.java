public class ComputeExp1
{
public static void main(String args[])
{
double num,a,b;
a=(25.5*3.5-3.5*3.5);
b=(40.5-4.5);
num=a/b;
System.out.println("Output is:"+num);

}
}


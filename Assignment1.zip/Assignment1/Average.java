import java.util.Scanner;
public class Average
{
public static void main(String args[])
{
int avg,a,b,c;
Scanner sc=new Scanner(System.in);
System.out.println("Enter three numbers:");
a=sc.nextInt();
b=sc.nextInt();
c=sc.nextInt();
avg=(a+b+c)/3;
System.out.println("Average is:"+avg);




}
}
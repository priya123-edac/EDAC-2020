import java.util.Scanner;
public class DivideNum
{
public static void main(String args[])
{
int a,b,res;
Scanner sc=new Scanner(System.in);
System.out.println("Enter  1st num:");
a=sc.nextInt();
System.out.println("Enter 2nd num:");
b=sc.nextInt();

res=a/b;
System.out.println("Final outpunt:"+res);// (a/b) operation returns quotient

}
}
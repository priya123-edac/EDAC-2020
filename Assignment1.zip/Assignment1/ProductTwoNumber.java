import java.util.Scanner;
public class ProductTwoNumber
{
public static void main(String args[])
{
int num1,num2,res;
Scanner sc= new Scanner(System.in);
System.out.println("Enter 1st num:");
num1=sc.nextInt();
System.out.println("Enter 2nd num:");
num2=sc.nextInt();
res=num1*num2;
System.out.println("Product is:"+res);
}
}

import java.util.Scanner;
public class OctalToDec{    
   public static void main(String args[]) {
	//octal value
	Scanner scanner = new Scanner(System.in);
	System.out.print("Enter Octal value: ");
	String octnum = scanner.nextLine();
	scanner.close();
		
	//octal to decimal using Integer.parseInt()
	int num = Integer.parseInt(octnum, 8);
		
	System.out.println("Decimal equivalent of value "+octnum+" is: "+num);
   }
}
import java.util.Scanner;
public class BinaryToOctal{
public static void main(String args[])
{
int num;
Scanner sc= new Scanner(System.in);
System.out.println("Binary to Octal Conversion");

		
System.out.println("\nEnter the number :");
num = Integer.parseInt(sc.nextLine(), 2);
sc.close();

String Octal = Integer.toOctalString(num);
System.out.println("Octal Value is : " + Octal);
}
}
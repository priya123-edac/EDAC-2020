import java.util.Scanner;
public class Rectangle
{
public static void main(String args[])
{
double hei,Wid,Area,Per;
Scanner sc=new Scanner(System.in);
System.out.println("Enter length value:");
hei=sc.nextDouble();
System.out.println("Enter breadth value:");
Wid=sc.nextDouble();
Are
a=hei*Wid; //Area of a rectangle =L*B
Per=2*(hei+Wid);//Perimeter of a rectangle =2(L+B)
System.out.println("Area of a rectangle is:"+Area);
System.out.println("Perimeter of a rectangle is:"+Per);
}
}
import java.util.Scanner;
public class Swap
{
public static void main(String args[])
{
int num1,num2,temp;
Scanner sc=new Scanner(System.in);
System.out.println("Enter two numbers:");
num1=sc.nextInt();
num2=sc.nextInt();

System.out.println("Before swap:" +" " +num1+" "+num2);
temp=num1;
num1=num2;
num2=temp;
System.out.println(num1+" "+num2);
sc.close();

}
}
import java.util.Scanner;
public class Circle
{
public static void main(String args[])
{
double R,Area,Per;
Scanner sc= new Scanner(System.in);
System.out.println("Enter radius value:");
R=sc.nextDouble();
Area=3.14*R*R;//Area of circle=3.14*R^2
Per=2*3.14*R;//Perimeter of circle =2*3.14*R
System.out.println("Area of a circle is:"+Area);
System.out.println("Perimeter of a circle is:"+Per);


}
}
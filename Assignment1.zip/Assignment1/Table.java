import java.util.Scanner;
public class Table
{
public static void main(String args[])
{
int num,res,i=0;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number:");
num=sc.nextInt();
System.out.printf("Table of"+num +"is:\n");
for(i=1;i<=10;i++)
{
res=num*i;
System.out.println(+num +"*"+i+"="+res);
}
}
}
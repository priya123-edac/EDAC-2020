import java.util.Scanner;
public class DecimalToBinary{
     
public static void main(String a[]){
int i;
Scanner sc=new Scanner(System.in);
i=sc.nextInt();
System.out.println(Integer.toBinaryString(i)); //converts decimal number into binary format
}
}

import java.util.Scanner;
public class Calculate
{
public static void main(String args[])
{
int num1,num2,sum,subt,mul,div,mod;
Scanner sc= new Scanner(System.in);//create object of scanner class
System.out.println("Enter num1:");
num1=sc.nextInt();
System.out.println("Enter num2:");
num2=sc.nextInt();
sum=num1+num2;
System.out.println("Product is:\n "+num1+"+" +num2 +"=" +sum);
}
}
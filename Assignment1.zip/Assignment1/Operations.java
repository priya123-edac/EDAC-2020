
public class Operations
{
public static void main(String args[])
{
int a,b,c,d;

a= -5+8*6;
b=(55+9)%9;
c=20+ -3*5/8;
d=5+15/3*2-8%3;
System.out.println("1st output:"+a);
System.out.println("2nd output:"+b);
System.out.println("3rd output:"+c);
System.out.println("4th output:"+d);
}
}
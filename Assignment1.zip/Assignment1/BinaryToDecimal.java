import java.util.Scanner;
public class BinaryToDecimal{
public static void main(String args[])
{
String binaryStr;
Scanner sc= new Scanner(System.in);
System.out.println("Enter binary number:");
binaryStr=sc.nextLine();
sc.close();
System.out.println("Output is:"+ Integer.parseInt(binaryStr,2));

     
}
}

create database final12;
use final12;
#Section 1)Create tables Publishers,Authors,Titles,titleauthors,subjects
#Publishers
create table Publishers
(
pubid numeric(7),
pname varchar(25),
phone varchar(30),
email varchar(100) UNIQUE,
primary key(pubid)
);

#Authors
create table Authors1(auid numeric(7),aname varchar(25),email varchar(50) UNIQUE,phone varchar(20),primary key(auid));

#Titles
create table Title1(
titleid numeric(10) primary key,
title varchar(50),
pubid numeric(7),
SUBID varchar(25),
pubdate date,
COVER CHAR(1) CHECK ( COVER IN ('P','H','p','h')),
PRICE int,
CONSTRAINT Publishers_pubid_FK FOREIGN KEY(pubid) REFERENCES Publishers(pubid),
CONSTRAINT Title1_SUBID_FK FOREIGN KEY(SUBID) REFERENCES subjects(SUBID)
);
#Subjects
create table subjects(SUBID varchar(25) primary key,subjectname varchar(50));

#titleauthors
CREATE TABLE  TITLEAUTHORS1
(
   titleid    numeric(10) ,
    auid      numeric(7) ,
    IMPORTANCE numeric(10),
   PRIMARY KEY(titleid,auid),
   CONSTRAINT  TITLESAUTHORS1_titleid_FK FOREIGN KEY (titleid) REFERENCES Title1(titleid),
   CONSTRAINT  TITLESAUTHORS1_auid_FK FOREIGN KEY (auid) REFERENCES Authors1(auid)
);

#Before inserting data display tables
select * from Publishers;
select * from Authors1;
select * from subjects;
select * from TITLEAUTHORS1;
select * from Title1;


#insert operation in all tables
insert into subjects values('ORA1','10g');
insert into subjects values('JEE','JAVA EDITION');
insert into subjects values('VB','VISUAL');
insert into subjects values('ASP','ASP.NET');

insert into Publishers values (1,'WILLEY','WDT@VSNL.NET.com','91-91-23260877');
insert into Publishers values (2,'WROX','INFO@WROX.COM',NULL);
insert into Publishers values (3,'TATA MCGRAW-HILL','FEEDBACK@TATAMCGRAWHILL.COM','91-33333322');
insert into Publishers values (4,'TECHMEDIA','BOOKS@TECHMEDIA.COM','933257660');

insert into Authors1 values(101, 'HERBERT SCHILD','HERBERT@YAHOO.COM',NULL);
insert into Authors1 values(102, 'JAMES GOODWILL','GOODWILL@HOTMAIL.COM',NULL);
insert into Authors1 values(103, 'DAVAID HUNTER','HUNTER@HOTMAIL.COM',NULL);
insert into Authors1 values(104, 'STEPHEN WALTHER','WALTHER@GMAIL.COM',NULL);
insert into Authors1 values(105, 'KEVIN LONEY','LONEY@ORACLE.COM',NULL);
insert into Authors1 values(106, 'ED. ROMANS','ROMANS@THESERVERSIDE.COM',NULL);

insert into Title1 values(1001,'ASP.NET UNLEASHED',4,'ASP',STR_TO_DATE('12-DEC-2020','%d-%M-%Y'),'P',540);
insert into Title1 values(1003,'MASTERING EJB',1,'JEE',STR_TO_DATE('3-FEB-05','%d-%M-%Y'),'P',475);
insert into Title1 values(2009,'ASP.NET UNLEASHED',4,'ASP',STR_TO_DATE('12-DEC-2020','%d-%M-%Y'),'P',540);
insert into Title1 values(2012,'ASP.NET UNLEASHED',4,'ASP',STR_TO_DATE('12-DEC-2020','%d-%M-%Y'),'P',540);

 INSERT INTO TITLEAUTHORS1 (titleid,auid,IMPORTANCE) VALUES (1001,101,1);
INSERT INTO TITLEAUTHORS1 VALUES (1003,102,1);
INSERT INTO TITLEAUTHORS1 VALUES (1003,103,1);
INSERT INTO TITLEAUTHORS1 VALUES (2009,104,1);
INSERT INTO TITLEAUTHORS1 VALUES (2012,105,2);

#after inserting data display all tables
select * from Publishers;
select * from Authors1;
select * from subjects;
select * from TITLEAUTHORS1;
select * from Title1;
#*********************************************************Display********************************************************
select pname,phone email from Publishers;
select aname,phone from Authors1;
select titleid, title, pubdate from Title1;
select auid, titleid, importance from TITLEAUTHORS1;

#**********************************************************(like)********************************************************
select subjectname from subjects where subjectname like 'oracle%';
select SUBID from subjects where SUBID like 'j%';
select SUBID from subjects where SUBID like '%.net%';
select aname from Authors1 where aname like '%er';
select aname from Authors1 where aname like '%er';
select pname from Publishers where pname like '%hill ';

#******************************************************(relational operator)****************************************************
select PRICE from Title1 where PRICE<500;
select pubdate from Title1 where pubdate<'2005-05-01';
select subjectname from subjects subject where SUBID= 'java' or 'jee';
select auid from Authors1 where auid>103;
select *from Title1 where titleid =101 or PRICE>400;

#**********************************************************(IN operator)****************************************************
/*Que)select all from publishers table  where publisher name is ('TECHMEDIA', 'WROX');*/
select * from Publishers where pname IN ('TECHMEDIA', 'WROX');

/*************************************************(aggregate function)********************************************
Que1)select maximum price from titles table. */
select MAX(PRICE) from Title1;
#Que2)	select average importance from titleauthors. 
SELECT AVG(IMPORTANCE) FROM TITLEAUTHORS1;

#Que3)select number of records from author table.
SELECT COUNT(auid) FROM Authors1;

#Que4)select sum of prices of all books.
         SELECT SUM(PRICE) FROM Title1;

/***********************************************************(date)****************************************************
Que1)select title from title table where month is 'Apr'.*/

SELECT COUNT(*) FROM Title1 WHERE MONTH(pubdate) = '04';

SELECT COUNT(*) FROM Title1 WHERE YEAR(pubdate) = '2002' AND MONTH(pubdate) = '04';

#Que2)	select year from system date.
SELECT YEAR('2020-12-05');

#Que3)select month from system date.
	SELECT MONTH('2020-12-05');
    
#Que4)select last day of month when 'java' book published.
 SELECT LAST_DAY(NOW());

/***************************************************(DML)**************************************************************
Que)create table Employee with emp_id (number),emp_name(char(50)) and insert some value.
1.	Add one column name 'dept_id ' in table name 'Employee';  */

create table employee(emp_id int ,emp_name char(50));

insert into employee values(102 , "Pratiksha"); 
insert into employee values(103 , "Neha");
insert into employee values(104 , "priti"); 
insert into employee values(105 , "Rupali"); 
insert into employee values(106, "Teju"); 

alter table employee add column dept_id varchar(3);  


#2. Change the datatype of column 'char' from tablename 'Employee' to 'varchar2'.
alter table employee modify column emp_name varchar(12);

#3) update name of employee to 'Scott'
 SET SQL_SAFE_UPDATES=0;
update employee set emp_name = "Scott" where emp_id=106;

#4)	truncate the table.
truncate table employee;
 
create table emp(SAL float(7,3));
insert into emp values(1234.567);
insert into emp values(1530.019);
insert into emp values(1652.786);
insert into emp values(1775.156);
desc emp;
select * from emp;

#)Perform following:
#1)round:
select round(1234.567);
select round(1775.156,2);
select round(1775.156,1);
select round(1775.156,0);

#2)truncate
select truncate(1.22 , 0);
select truncate(23.44 , 1);
select truncate(234.34*100 , 1);
select truncate(45.676 , -2);

#3)ceil
select ceil(8.1);
select ceil(1775.156);

#4)floor
select floor(1775.156);
select floor(8.1);

#5)sign
select sign(-1775.156);
select sign(1775.156);
select sign(0);

#6)mod
select mod(23,2);
select mod(12,2);

#7)sqrt
select sqrt(4);
select sqrt(3);

#8)power
select power(2,2);
select power(12,3);
select power(2,3);

#Q)perform all string function on string "CDAC juhu".
select char_length("CDAC  juhu");
select concat("CDAC","JUHU");
select concat('CDA','C','  ',"juhu");
select concat_ws(" - ", 'CDAC','juhu');
select find_in_set('a' , "f,g,k,a,b");
select find_in_set('a' , "fgkab");
select find_in_set('ju',"cdac,ju,juhu");
select find_in_set('ju',"cdac ,ju,juhu");
select find_in_set('ju',"cdac,ju,juhu");
select locate("u", "cadc juhu");
select locate("uhu", "cadc juhu");
select lower("CADC JUHU");
select lower("Cadc JUHU");
select repeat("CDAC-" , 3);
select repeat("CDAC - " , 3);
select replace("CDAC juhu",'u','kh');
select reverse("CDAC juhu");
select space(3);
select strcmp("CADC","CADC");
select strcmp("CDAC","juhu");
select strcmp("juhu" , "CDAC");
select substring("CADC mumbai",4);
select substring("CADC mumbai", 6 , 3);

select upper("cdac");
select unhex("cdac");
select UNHEX("cdac");
select UNHEX('WWW');
select hex('www');
select ucase('www');
select format(5273.2474,2);
select position("ac" in "cdacmumbai");
select make_Set(1|4,"c","d","a","c","m");
select make_Set(1|4|2,"c","d","a","c","m");
select elt(1,"c","d","a","c");
select elt(1,"cdac");
select elt(0,"c","d","a","c");
select elt(5,"c","d","a","c");
select left("cdacmumbai",4);
select right("cdacmumbai",4);
select length("cdac");
select mid("cdacmumbai",2,3);
SELECT ASCII('CDAC juhu');
SELECT BIN('CDAC');

#Q)perform different date and time functions. 
select sysdate();
select current_date();
select current_date()+1;
SELECT CURDATE()+0;
select CURRENT_TIME();
select current_time()+0;
select monthname("1998-08-16");
select dayname("1996-11-06");
select dayofweek("1998-08-16");
SELECT LAST_DAY('1998-08-16');
select makedate(2021,130);
 SELECT HOUR('11:05:03');
 select now();
 SELECT DATE_ADD('1998-07-16', INTERVAL 31 DAY);





 










